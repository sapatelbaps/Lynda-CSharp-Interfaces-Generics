﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaces
{

    class Program
    {
        static void Main(string[] args) {

            Console.WriteLine("\nPress Enter key to continue...");
            Console.ReadLine();
        }
    }
}
