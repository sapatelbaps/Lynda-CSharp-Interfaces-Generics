﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StacksQueues
{
    class Program
    {
        static void Main(string[] args) {
            // create a new stack to hold the names of sports
            Stack<string> sportsStack = new Stack<string>();


            // QUEUE
            Queue<string> sportsQueue = new Queue<string>();


            Console.WriteLine("\nPress Enter key to continue...");
            Console.ReadLine();
        }
    }
}
